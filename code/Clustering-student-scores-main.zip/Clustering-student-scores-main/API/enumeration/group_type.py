from enum import Enum


class Recommend_Type(Enum):
    SUB_RECOMMEND = "Sub recommend",
    MAIN_RECOMMEND = "Main recommend"
