export const environment = {
  production: true,
  baseApiUrl: 'http://localhost:5000',
};
